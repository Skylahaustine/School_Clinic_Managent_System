<!--header area-->
<?php
    include 'theme/header.php';
    include 'theme/sidebar.php';
    include 'theme/breadcrumbs.php'; 
    include 'theme/iconcards.php';
    include 'theme/footer.php';
?>