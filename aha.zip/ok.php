<?php
include "includes/connection.php";
if ($confirm==$password) {
    # code...
if (isset($_POST['register'])) {
# code…
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$password=$_POST['password'];
$confirm=$_POST['confirm'];
$status=$_POST['status'];
$sqli = "INSERT INTO admin (firstname,lastname,username,password,status) VALUES ('".$firstname."','".$lastname."','".$email."',md5('".$password."'),'".$status."')";
$res = mysqli_query($db,$sqli);
?>
<script>
    alert('Successfully Added!');
    window.location = 'login.php';
</script>
<?php
mysqli_close($con);
//include "login.php";
}
}
else{
    
    include "register.php";
}
?>
 